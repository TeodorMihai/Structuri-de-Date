#ifndef __lista_hard
#define __lista_hard



int convert(char c) {

	if(isdigit(c))
		return c - '0';
	else  return c - 'A' + 10;
}

char reconvert(int x) {

	if(x < 10)
		return x + '0';
	else return x + 'A' - 10;
}

void _NodHard(NodHard* nod, int _ind, int _line, int _damage, char* _adr) {

	nod->ind = _ind;
	nod->line = _line;
	nod->damage = _damage;

	nod->adr = convert(_adr[0]) + (convert(_adr[1]) << 4) + (convert(_adr[2]) << 8) + (convert(_adr[3]) << 12);
}

char* get_address(unsigned int x) {

	char* s = malloc(sizeof(char) * 6);
	int mask = (1 << 4) - 1;

	s[0] = reconvert(x & mask);
	s[1] = reconvert(x >> 4 & mask);
	s[2] = reconvert(x >> 8 & mask);
	s[3] = reconvert(x >> 12 & mask);
	s[4] = '\0';

	return s;
}

void move_toward(NodHard** nod, int ind, int line) {


	if((*nod)->ind == 0) {
		
		if((*nod)->line < line) {

			(*nod) = (*nod)->up;
			return ;
		}
		
		if((*nod)->line > line) {
			(*nod) = (*nod)->down;
			return ;
		}

		if((*nod)->line == line && (*nod)->ind != ind) {
			(*nod) = (*nod)->next;
			return ;
		}
	} else {

		if((*nod)->line != line || (*nod)->ind != ind)
			//if((*nod)->next != NULL)
				(*nod) = (*nod)->next;
	}


}


void printNodHard(NodHard* nod, FILE* out) {

	fprintf(out, "indice: %d, linie: %d, damage: %d, adresa: %s\n", nod->ind, nod->line, nod->damage, get_address(nod->adr) );
}


void __NodHard(NodHard *nod) {

	nod->up = NULL;
	nod->down = NULL;
	nod->next = NULL;
}

NodHard* create_list(int max_lines) { 

	NodHard* first_Nod_old_line = malloc(sizeof(NodHard));
	NodHard* to_return = malloc(sizeof(NodHard));

	__NodHard(first_Nod_old_line);
	__NodHard(to_return);

	int cnt = 4;

	for(int i = 0 ; i < max_lines; ++i) {

		int number_elements = (1 << cnt);

		NodHard* first = malloc(sizeof(NodHard));
		__NodHard(first);

		if(i == 0) {

			_NodHard(first, 0, 0, 0, "0000");

			first->down = NULL;
			first_Nod_old_line = first;
			to_return = first;
	
		} else {

			first->down = first_Nod_old_line;
			first->up = NULL;
			_NodHard(first, 0, i, 0, "0000");
			first_Nod_old_line->up = first;
			first_Nod_old_line = first;

		}

		NodHard* old_Nod = first;


		for(int j = 1; j < number_elements; ++j) {

			NodHard* cur = malloc(sizeof(NodHard));
			__NodHard(cur);

			if(j == number_elements - 1) {

				_NodHard(cur, j, i, 0 , "0000");
			
				cur->next = first;
				cur->up = NULL;
				cur->down = NULL;
				old_Nod->next = cur;

				continue;
			}

			_NodHard(cur, j, i, 0 , "0000");
			cur->next = NULL;
			cur->up = NULL;
			cur->down = NULL;

			old_Nod->next = cur;
			old_Nod = cur;
		}

		++cnt;

	}
	return to_return;
}

void print_hard_disk(NodHard* first, int max_lines, FILE *out) {

	int cnt = 4;
	for(int i = 0 ;i < max_lines; ++i) {

		int number_elements = (1 << cnt);
		for(int j = 0 ; j < number_elements ; ++j) {
		
			
			//fprintf(out, "::r %d %d\n2\n", first->line, first->ind);
			first = first->next;
		}

		if(first->up == NULL)
			fprintf(out, "laldaslas");
		
		first = first->up;
		cnt++;
	}

}



#endif