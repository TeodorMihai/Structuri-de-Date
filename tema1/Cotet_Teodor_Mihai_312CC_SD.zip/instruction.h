#ifndef __instruction
#define __instruction

//char *s = NULL;

char* get_type(char **s) {

	int cnt = 0;

	char* to_return = malloc(sizeof(char) * 10);

	while(**s != '\0' && !isalpha(**s)) ++(*s);
	
	while(**s != '\0' && isalpha(**s)) to_return[cnt++] = **s, ++(*s);

	to_return[cnt] = '\0';
	
	return to_return;
}

int get_number(char **s) {

	int number = 0;

	while(**s != '\0' && !isdigit(**s)) ++(*s);
	
	while(**s != '\0' && isdigit(**s)) number = number * 10 + (**s) - '0' , ++(*s);

	return number;
}


Instruction get_instruction(FILE* in, FILE *out) {

	Instruction instr;

	instr.type = malloc(sizeof(char) * 5);
	instr.line = instr.ind = instr.tmp = 0;
	
	char *s = malloc(100 * sizeof(char));
	
	fgets(s, 100, in);

	
	strcpy(instr.type, get_type(&s));

	if(strcmp(instr.type, "e") == 0)
		return instr;

	instr.line = get_number(&s);
	instr.ind = get_number(&s);

	if(strcmp(instr.type, "w") == 0) {

		int cnt = 0;
		instr.code = malloc(sizeof(char) * 6);	

		while(*s != '\0' && !isalnum(*s)) ++s;
		while(*s != '\0' && isalnum(*s)) instr.code[cnt++] = *s, ++s;

		instr.code[cnt] = '\0';
	}

	return instr;
}


void printInstruction(Instruction x, FILE* out) {

	fprintf(out, "type: %s  line: %d  index: %d   time : %d  \n", x.type, x.line, x.ind, x.tmp );
}

#endif