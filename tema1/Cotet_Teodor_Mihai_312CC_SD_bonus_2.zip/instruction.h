#ifndef __instruction
#define __instruction


char* get_type(char **s) {

	int cnt = 0;

	char* to_return = malloc(sizeof(char) * 10);

	while(**s != '\0' && !isalpha(**s)) ++(*s);
	
	while(**s != '\0' && isalpha(**s)) to_return[cnt++] = **s, ++(*s);

	to_return[cnt] = '\0';
	
	return to_return;
}

int get_number(char **s) {

	int number = 0;

	while(**s != '\0' && !isdigit(**s)) ++(*s);
	
	while(**s != '\0' && isdigit(**s)) number = number * 10 + (**s) - '0' , ++(*s);

	return number;
}


Instruction* get_instruction(FILE* in, FILE *out) {

	Instruction* instr = malloc(sizeof(Instruction));

	instr[0].type = malloc(sizeof(char) * 5);
	instr[0].line = instr[0].ind = instr[0].tmp = 0;
	
	char *s = malloc(600000 * sizeof(char));
	
	fgets(s, 600000, in);
	
	strcpy(instr[0].type, get_type(&s));


	instr[0].nr = 1;

	if(strcmp(instr[0].type, "e") == 0)
		return instr;

	instr[0].line = get_number(&s);
	instr[0].ind = get_number(&s);


	if(strcmp(instr[0].type, "w") == 0) {

		int cnt = 0;
		instr[0].code = malloc(sizeof(char) * 6);	

		while(*s != '\0' && !isalnum(*s)) ++s;
		while(*s != '\0' && isalnum(*s)) instr[0].code[cnt++] = *s, ++s;

		instr[0].code[cnt] = '\0';
		return instr;
	}

	if(strcmp(instr[0].type, "r") == 0)
		return instr;
	if(strcmp(instr[0].type, "d") == 0)
		return instr;

	if(strcmp(instr[0].type, "mr") == 0) {
		
		int nr = get_number(&s);

		instr = realloc( instr, (nr + 1) * sizeof(Instruction));
		instr[0].nr = nr;

		for(int i = 1; i < nr; ++i) {

			instr[i].type = malloc(sizeof(char) * 5);
			strcpy(instr[i].type, instr[i - 1].type);

			instr[i].line = instr[i - 1].line;
			instr[i].ind =  instr[i - 1].ind + 1;

			if(instr[i].ind == (1 << (instr[i].line + 4) ) ) {
			
				instr[i].line++;
				instr[i].ind = 0;
			}
		
		}		
	}

	if(strcmp(instr[0].type, "mw") == 0) { 
		
		int nr = 0; //prima data sa baga prima adresa

		int cnt = 0 ;

		instr[0].code = malloc(sizeof(char) * 5);	

		while(*s != '\0' && !isalnum(*s)) ++s;
		while(*s != '\0' && *s != '.' && isalnum(*s)) instr[0].code[cnt++] = *s, ++s;

		instr[0].code[cnt] = '\0';

		while(1) {

			nr++ ;
			cnt = 0 ;

			instr = realloc(instr, (nr + 2) * sizeof(Instruction));
			
			instr[nr].line = instr[nr - 1].line;
			instr[nr].ind =  instr[nr- 1].ind + 1;

			if(instr[nr].ind == (1 << (instr[nr].line + 4) ) ) {
		
				instr[nr].line++;
				instr[nr].ind = 0;
			}


			instr[nr].type = malloc(4 *sizeof(char));
			strcpy(instr[nr].type, "mw");

			instr[nr].code = malloc(sizeof(char) * 5);	

			while(*s != '\0' && *s != '.' && !isalnum(*s)) ++s;
			while(*s != '\0' && *s != '.' && isalnum(*s)) instr[nr].code[cnt++] = *s, ++s;

			instr[nr].code[cnt] = '\0'; 

			if(*s == '.' || *s == '\0') {
			
				instr[0].nr = nr;
				break;
			} 
		}
	}

	return instr;
}


void printInstruction(Instruction x, FILE* out) {


	fprintf(out, "type: %s  line: %d  index: %d   time : %d ", x.type, x.line, x.ind, x.tmp );
	if(strcmp(x.type, "w") == 0 || strcmp(x.type, "mw") == 0)
		fprintf(out, "codul:  %s  ", x.code );
	fprintf(out, "\n");
}

#endif