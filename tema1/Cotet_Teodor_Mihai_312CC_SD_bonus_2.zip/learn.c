#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
	
	char *s = malloc(100);
	gets(s);
	while(*s) printf("%c", *s), ++s;
	return 0;
}