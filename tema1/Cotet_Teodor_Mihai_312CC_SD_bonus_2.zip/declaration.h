#ifndef __declaration
#define __declaration


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <limits.h>


const int READ_DATA = 5;
const int WRITE = 30;
const int READ_DAMAGE = 2;

typedef struct Instruction {

	char* type;
	int line;
	int ind;
	char *code;
	int tmp;
	int nr;

} Instruction;


#define data_type Instruction

typedef struct Nod {

	data_type inf;
	struct Nod* next;
} Nod;


typedef struct NodHard {

	
	int ind;
	int line;
	
	int damage;
	unsigned short int adr;

	struct NodHard* next;
	struct NodHard* up;
	struct NodHard* down;

} NodHard;

#endif
